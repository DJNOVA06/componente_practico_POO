from models.paciente_domestico import Paciente_domestico
from utils import validar_datos as v


class Paciente_hospitalizado(Paciente_domestico):
    def __init__(self, id_hospitalizado, fecha_ingreso, fecha_alta, motivo_ingreso, diagnostico,
                 veterinario_responsable, numero_jaula, costo_diario, estado_hospitalizacion,
                 lista_medicacion, **datos_domestico):
        super().__init__(**datos_domestico)
        self.id_hospitalizado = id_hospitalizado
        self.fecha_ingreso = fecha_ingreso
        self.fecha_alta = fecha_alta
        self.motivo_ingreso = motivo_ingreso
        self.diagnostico = diagnostico
        self.veterinario_responsable = veterinario_responsable
        self.numero_jaula = numero_jaula
        self.costo_diario = costo_diario
        self.estado_hospitalizacion = estado_hospitalizacion
        self.lista_medicacion = list(lista_medicacion) if lista_medicacion else []

    def calcular_dias_hospitalizacion(self, fecha_actual=None):
        """Dias entre el ingreso y el alta (o fecha_actual / hoy si sigue internado). Minimo 1."""
        ingreso = v.a_fecha(self.fecha_ingreso, 'fecha_ingreso')
        if self.fecha_alta:
            fin = v.a_fecha(self.fecha_alta, 'fecha_alta')
        else:
            fin = v.a_fecha_o_hoy(fecha_actual, 'fecha_actual')
        dias = (fin - ingreso).days
        if dias < 0:
            raise ValueError('la fecha de referencia es anterior a la fecha de ingreso')
        return max(dias, 1)

    def calcular_costo_hospitalizacion(self, fecha_actual=None):
        dias = self.calcular_dias_hospitalizacion(fecha_actual)
        return round(dias * float(self.costo_diario), 2)
