from datetime import date
from utils import validar_datos as v


class Paciente_animal:
    def __init__(self, id_paciente, nombre, especie, raza, sexo,
                 fecha_nacimiento, peso, color, estado_salud, fecha_registro):
        self.id_paciente = id_paciente
        self.nombre = nombre
        self.especie = especie
        self.raza = raza
        self.sexo = sexo
        self.fecha_nacimiento = fecha_nacimiento
        self.peso = peso
        self.color = color
        self.estado_salud = estado_salud
        self.fecha_registro = fecha_registro

    @property
    def edad(self):
        """Edad en anios, calculada a partir de fecha_nacimiento."""
        nacimiento = v.a_fecha(self.fecha_nacimiento, 'fecha_nacimiento')
        hoy = date.today()
        return hoy.year - nacimiento.year - ((hoy.month, hoy.day) < (nacimiento.month, nacimiento.day))

    def actualizar_estado_salud(self, nuevo_estado):
        self.estado_salud = v.opcion(nuevo_estado, 'estado_salud', v.ESTADOS_SALUD)

    def registrar_peso(self, nuevo_peso):
        self.peso = v.numero(nuevo_peso, 'peso', minimo=0, minimo_exclusivo=True)
