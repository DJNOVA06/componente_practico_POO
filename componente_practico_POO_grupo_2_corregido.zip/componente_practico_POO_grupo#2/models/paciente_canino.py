from models.paciente_domestico import Paciente_domestico
from utils import validar_datos as v


class Paciente_canino(Paciente_domestico):
    def __init__(self, id_canino, tamanio, tipo_pelaje, desparasitaciones, vacuna_rabia,
                 vacuna_parvovirus, raza_peligrosa, usar_bozal, esta_adiestrado,
                 nivel_energia, **datos_domestico):
        super().__init__(**datos_domestico)
        self.id_canino = id_canino
        self.tamanio = tamanio
        self.tipo_pelaje = tipo_pelaje
        self.desparasitaciones = list(desparasitaciones) if desparasitaciones else []
        self.vacuna_rabia = vacuna_rabia
        self.vacuna_parvovirus = vacuna_parvovirus
        self.raza_peligrosa = raza_peligrosa
        self.usar_bozal = usar_bozal
        self.esta_adiestrado = esta_adiestrado
        self.nivel_energia = nivel_energia

    def registrar_desparasitacion(self, fecha):
        fecha = v.fecha(fecha, 'fecha de desparasitacion', no_futura=True)
        self.desparasitaciones.append(fecha)
        self.desparasitaciones.sort()

    def calcular_edad_canina(self):
        """Formula simple: 1 anio humano = 7 anios de perro."""
        return self.edad * 7
