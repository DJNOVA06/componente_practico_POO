from models.paciente_animal import Paciente_animal
from utils import validar_datos as v


class Paciente_domestico(Paciente_animal):
    def __init__(self, id_propietario, propietario_nombre, propietario_cedula, propietario_telefono,
                 propietario_direccion, propietario_correo, vacunas, fecha_ultima_vacuna,
                 esta_esterilizado, tiene_microchip, **datos_animal):
        super().__init__(**datos_animal)
        self.id_propietario = id_propietario
        self.propietario_nombre = propietario_nombre
        self.propietario_cedula = propietario_cedula
        self.propietario_telefono = propietario_telefono
        self.propietario_direccion = propietario_direccion
        self.propietario_correo = propietario_correo
        self.vacunas = list(vacunas) if vacunas else []
        self.fecha_ultima_vacuna = fecha_ultima_vacuna
        self.esta_esterilizado = esta_esterilizado
        self.tiene_microchip = tiene_microchip

    def registrar_propietario(self, nombre, cedula, telefono, direccion, correo=''):
        # se valida todo primero, asi no queda el objeto a medio actualizar
        nombre = v.solo_letras(nombre, 'propietario_nombre')
        cedula = v.cedula(cedula)
        telefono = v.telefono(telefono)
        direccion = v.texto(direccion, 'propietario_direccion')
        correo = v.correo(correo)
        self.propietario_nombre = nombre
        self.propietario_cedula = cedula
        self.propietario_telefono = telefono
        self.propietario_direccion = direccion
        self.propietario_correo = correo

    def registrar_vacuna(self, vacuna, fecha):
        vacuna = v.texto(vacuna, 'vacuna')
        fecha = v.fecha(fecha, 'fecha de la vacuna', no_futura=True)
        self.vacunas.append(vacuna)
        if not self.fecha_ultima_vacuna or fecha > self.fecha_ultima_vacuna:
            self.fecha_ultima_vacuna = fecha
