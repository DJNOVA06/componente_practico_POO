from datetime import date
from models.paciente_hospitalizado import Paciente_hospitalizado
from utils import validar_datos as v


class Paciente_cuidados_intensivos(Paciente_hospitalizado):
    def __init__(self, id_intensivo, nivel_gravedad, requiere_oxigeno, requiere_ventilacion,
                 frecuencia_monitoreo_h, temperatura, frecuencia_cardiaca, frecuencia_respiratoria,
                 recargo_porcentaje, equipo_asignado, registros_monitoreo=None, **datos_hospitalizado):
        super().__init__(**datos_hospitalizado)
        self.id_intensivo = id_intensivo
        self.nivel_gravedad = nivel_gravedad
        self.requiere_oxigeno = requiere_oxigeno
        self.requiere_ventilacion = requiere_ventilacion
        self.frecuencia_monitoreo_h = frecuencia_monitoreo_h
        self.temperatura = temperatura
        self.frecuencia_cardiaca = frecuencia_cardiaca
        self.frecuencia_respiratoria = frecuencia_respiratoria
        self.recargo_porcentaje = recargo_porcentaje
        self.equipo_asignado = list(equipo_asignado) if equipo_asignado else []
        self.registros_monitoreo = list(registros_monitoreo) if registros_monitoreo else []

    def registrar_monitoreo(self, frecuencia_cardiaca, frecuencia_respiratoria, temperatura):
        fc = v.numero(frecuencia_cardiaca, 'frecuencia_cardiaca', minimo=0, minimo_exclusivo=True, entero=True)
        fr = v.numero(frecuencia_respiratoria, 'frecuencia_respiratoria', minimo=0, minimo_exclusivo=True, entero=True)
        temp = v.numero(temperatura, 'temperatura', minimo=25, maximo=45)
        self.frecuencia_cardiaca = fc
        self.frecuencia_respiratoria = fr
        self.temperatura = temp
        self.registros_monitoreo.append({
            'fecha': date.today().isoformat(),
            'frecuencia_cardiaca': fc,
            'frecuencia_respiratoria': fr,
            'temperatura': temp,
        })

    def calcular_recargo_cuidados(self, fecha_actual=None):
        """Recargo = costo de hospitalizacion x recargo_porcentaje / 100."""
        costo_base = self.calcular_costo_hospitalizacion(fecha_actual)
        return round(costo_base * float(self.recargo_porcentaje) / 100, 2)
