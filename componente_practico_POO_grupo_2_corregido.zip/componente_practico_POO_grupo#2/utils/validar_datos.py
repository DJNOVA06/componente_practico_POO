import math
from datetime import date, datetime

CONFIRMAR = ('si', 's', 'yes', 'y')
NEGAR = ('no', 'n')

SEXOS = ('macho', 'hembra')
ESTADOS_SALUD = ('bueno', 'medio', 'malo')
TAMANIOS = ('pequeno', 'mediano', 'grande')
NIVELES_ENERGIA = ('alto', 'medio', 'bajo')
ESTADOS_HOSPITALIZACION = ('activo', 'alta medica')
NIVELES_GRAVEDAD = ('bajo', 'medio', 'alto')

_SIN_ACENTOS = str.maketrans('áéíóúñ', 'aeioun')


# ---------------------------------------------------------------
# Validadores basicos: reciben el texto escrito y devuelven el valor
# ya convertido. Si algo esta mal lanzan ValueError con un mensaje claro.
# ---------------------------------------------------------------
def texto(valor, campo, obligatorio=True):
    valor = str(valor).strip()
    if obligatorio and not valor:
        raise ValueError(f'{campo} no puede estar vacio')
    return valor


def solo_letras(valor, campo, obligatorio=True):
    valor = texto(valor, campo, obligatorio)
    if valor and not all(c.isalpha() or c in " .'-" for c in valor):
        raise ValueError(f'{campo} solo puede contener letras')
    return valor


def numero(valor, campo, minimo=None, maximo=None, entero=False, minimo_exclusivo=False):
    try:
        n = float(str(valor).replace(',', '.').strip())
    except ValueError:
        raise ValueError(f'{campo} debe ser un numero')
    if not math.isfinite(n):
        raise ValueError(f'{campo} debe ser un numero valido')
    if entero:
        if n != int(n):
            raise ValueError(f'{campo} debe ser un numero entero')
        n = int(n)
    if minimo is not None and (n < minimo or (minimo_exclusivo and n == minimo)):
        simbolo = '>' if minimo_exclusivo else '>='
        raise ValueError(f'{campo} debe ser {simbolo} {minimo}')
    if maximo is not None and n > maximo:
        raise ValueError(f'{campo} debe ser <= {maximo}')
    return n


def a_fecha(valor, campo='fecha'):
    try:
        return datetime.strptime(str(valor).strip(), '%Y-%m-%d').date()
    except ValueError:
        raise ValueError(f'{campo} no es una fecha valida (use AAAA-MM-DD)')


def a_fecha_o_hoy(valor, campo='fecha'):
    if valor is None or str(valor).strip() == '':
        return date.today()
    return a_fecha(valor, campo)


def fecha(valor, campo, obligatoria=True, no_futura=False):
    """Devuelve la fecha como texto 'AAAA-MM-DD' (o None si es opcional y esta vacia)."""
    if valor is None or str(valor).strip() == '':
        if obligatoria:
            raise ValueError(f'{campo} es obligatoria (formato AAAA-MM-DD)')
        return None
    f = a_fecha(valor, campo)
    if no_futura and f > date.today():
        raise ValueError(f'{campo} no puede ser una fecha futura')
    return f.isoformat()


def si_no(valor, campo):
    v = str(valor).strip().lower().translate(_SIN_ACENTOS)
    if v in CONFIRMAR:
        return True
    if v in NEGAR:
        return False
    raise ValueError(f'{campo} debe responderse con si o no')


def opcion(valor, campo, validas):
    v = str(valor).strip().lower().translate(_SIN_ACENTOS)
    if v not in validas:
        raise ValueError(f"{campo} debe ser una de estas opciones: {', '.join(validas)}")
    return v


def lista(valor):
    elementos = valor if isinstance(valor, list) else str(valor).split(',')
    return [str(e).strip() for e in elementos if str(e).strip()]


def lista_fechas(valor, campo):
    return sorted(fecha(f, campo, no_futura=True) for f in lista(valor))


def cedula(valor, campo='propietario_cedula'):
    valor = texto(valor, campo)
    if not (valor.isdigit() and len(valor) == 10):
        raise ValueError(f'{campo} debe tener 10 digitos')
    return valor


def telefono(valor, campo='propietario_telefono'):
    valor = texto(valor, campo)
    if not (valor.isdigit() and 7 <= len(valor) <= 10):
        raise ValueError(f'{campo} debe tener entre 7 y 10 digitos')
    return valor


def correo(valor, campo='propietario_correo'):
    valor = str(valor).strip()
    if not valor:
        return ''
    if valor.count('@') != 1:
        raise ValueError(f'{campo} no es un correo valido')
    usuario, dominio = valor.split('@')
    if not usuario or '.' not in dominio or dominio.startswith('.') or dominio.endswith('.'):
        raise ValueError(f'{campo} no es un correo valido')
    return valor


def id_valido(valor, campo):
    return numero(valor, campo, minimo=1, entero=True)


# ---------------------------------------------------------------
# Validacion de cada tipo de paciente. Devuelven un diccionario nuevo
# con los datos convertidos o lanzan ValueError.
# ---------------------------------------------------------------
def validar_datos_animal(d):
    nacimiento = fecha(d['fecha_nacimiento'], 'fecha_nacimiento', no_futura=True)
    registro = fecha(d['fecha_registro'] or date.today().isoformat(), 'fecha_registro', no_futura=True)
    if registro < nacimiento:
        raise ValueError('fecha_registro no puede ser anterior a fecha_nacimiento')
    return {
        'nombre': solo_letras(d['nombre'], 'nombre'),
        'especie': solo_letras(d['especie'], 'especie'),
        'raza': solo_letras(d['raza'], 'raza'),
        'sexo': opcion(d['sexo'], 'sexo', SEXOS),
        'fecha_nacimiento': nacimiento,
        'peso': numero(d['peso'], 'peso', minimo=0, minimo_exclusivo=True),
        'color': solo_letras(d['color'], 'color'),
        'estado_salud': opcion(d['estado_salud'], 'estado_salud', ESTADOS_SALUD),
        'fecha_registro': registro,
    }


def validar_datos_domestico(d):
    return {
        'id_paciente': id_valido(d['id_paciente'], 'id_paciente'),
        'propietario_nombre': solo_letras(d['propietario_nombre'], 'propietario_nombre'),
        'propietario_cedula': cedula(d['propietario_cedula']),
        'propietario_telefono': telefono(d['propietario_telefono']),
        'propietario_direccion': texto(d['propietario_direccion'], 'propietario_direccion'),
        'propietario_correo': correo(d['propietario_correo']),
        'vacunas': lista(d['vacunas']),
        'fecha_ultima_vacuna': fecha(d['fecha_ultima_vacuna'], 'fecha_ultima_vacuna',
                                     obligatoria=False, no_futura=True),
        'esta_esterilizado': si_no(d['esta_esterilizado'], 'esta_esterilizado'),
        'tiene_microchip': si_no(d['tiene_microchip'], 'tiene_microchip'),
    }


def validar_datos_canino(d):
    return {
        'id_propietario': id_valido(d['id_propietario'], 'id_propietario'),
        'tamanio': opcion(d['tamanio'], 'tamanio', TAMANIOS),
        'tipo_pelaje': solo_letras(d['tipo_pelaje'], 'tipo_pelaje'),
        'desparasitaciones': lista_fechas(d['desparasitaciones'], 'desparasitaciones'),
        'vacuna_rabia': si_no(d['vacuna_rabia'], 'vacuna_rabia'),
        'vacuna_parvovirus': si_no(d['vacuna_parvovirus'], 'vacuna_parvovirus'),
        'raza_peligrosa': si_no(d['raza_peligrosa'], 'raza_peligrosa'),
        'usar_bozal': si_no(d['usar_bozal'], 'usar_bozal'),
        'esta_adiestrado': si_no(d['esta_adiestrado'], 'esta_adiestrado'),
        'nivel_energia': opcion(d['nivel_energia'], 'nivel_energia', NIVELES_ENERGIA),
    }


def validar_datos_hospitalizado(d):
    ingreso = fecha(d['fecha_ingreso'], 'fecha_ingreso', no_futura=True)
    alta = fecha(d['fecha_alta'], 'fecha_alta', obligatoria=False, no_futura=True)
    estado = opcion(d['estado_hospitalizacion'], 'estado_hospitalizacion', ESTADOS_HOSPITALIZACION)
    if alta and alta < ingreso:
        raise ValueError('fecha_alta no puede ser anterior a fecha_ingreso')
    if estado == 'activo' and alta:
        raise ValueError("un paciente 'activo' no puede tener fecha_alta")
    if estado == 'alta medica' and not alta:
        raise ValueError("un paciente con 'alta medica' necesita fecha_alta")
    return {
        'id_propietario': id_valido(d['id_propietario'], 'id_propietario'),
        'fecha_ingreso': ingreso,
        'fecha_alta': alta,
        'motivo_ingreso': texto(d['motivo_ingreso'], 'motivo_ingreso'),
        'diagnostico': texto(d['diagnostico'], 'diagnostico'),
        'veterinario_responsable': solo_letras(d['veterinario_responsable'], 'veterinario_responsable'),
        'numero_jaula': numero(d['numero_jaula'], 'numero_jaula', minimo=1, entero=True),
        'costo_diario': round(numero(d['costo_diario'], 'costo_diario', minimo=0), 2),
        'estado_hospitalizacion': estado,
        'lista_medicacion': lista(d['lista_medicacion']),
    }


def validar_datos_intensivo(d):
    return {
        'id_hospitalizado': id_valido(d['id_hospitalizado'], 'id_hospitalizado'),
        'nivel_gravedad': opcion(d['nivel_gravedad'], 'nivel_gravedad', NIVELES_GRAVEDAD),
        'requiere_oxigeno': si_no(d['requiere_oxigeno'], 'requiere_oxigeno'),
        'requiere_ventilacion': si_no(d['requiere_ventilacion'], 'requiere_ventilacion'),
        'frecuencia_monitoreo_h': numero(d['frecuencia_monitoreo_h'], 'frecuencia_monitoreo_h',
                                         minimo=0, minimo_exclusivo=True),
        'temperatura': numero(d['temperatura'], 'temperatura', minimo=25, maximo=45),
        'frecuencia_cardiaca': numero(d['frecuencia_cardiaca'], 'frecuencia_cardiaca',
                                      minimo=0, minimo_exclusivo=True, entero=True),
        'frecuencia_respiratoria': numero(d['frecuencia_respiratoria'], 'frecuencia_respiratoria',
                                          minimo=0, minimo_exclusivo=True, entero=True),
        'recargo_porcentaje': numero(d['recargo_porcentaje'], 'recargo_porcentaje', minimo=0, maximo=100),
        'equipo_asignado': lista(d['equipo_asignado']),
    }


VALIDADORES = {
    'animal': validar_datos_animal,
    'domestico': validar_datos_domestico,
    'canino': validar_datos_canino,
    'hospitalizado': validar_datos_hospitalizado,
    'intensivo': validar_datos_intensivo,
}


def verificar_datos(tipo, datos):
    """Valida los datos de un tipo ('animal', 'domestico', ...). Lanza ValueError si hay un error."""
    return VALIDADORES[tipo](datos)
