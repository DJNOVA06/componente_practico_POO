def generar_id_animal(datos):
    datos['ultimo_id_animal'] += 1

    return datos['ultimo_id_animal']

def generar_id_domestico(datos):
    datos['ultimo_id_domestico'] += 1

    return datos['ultimo_id_domestico']

def generar_id_canino(datos):
    datos['ultimo_id_canino'] += 1

    return datos['ultimo_id_canino']

def generar_id_hospitalizado(datos):
    datos['ultimo_id_hospitalizado'] += 1

    return datos['ultimo_id_hospitalizado']

def generar_id_intensivo(datos):
    datos['ultimo_id_intensivo'] += 1

    return datos['ultimo_id_intensivo']
