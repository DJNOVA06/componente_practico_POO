import copy
import json
import os

# Ruta absoluta: funciona sin importar desde que carpeta se ejecute el programa
RUTA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'db.json')

DATOS_INICIACION = {
    'ultimo_id_animal': 0,
    'ultimo_id_domestico': 0,
    'ultimo_id_canino': 0,
    'ultimo_id_hospitalizado': 0,
    'ultimo_id_intensivo': 0,
    'animales': [],
    'domesticos': [],
    'caninos': [],
    'hospitalizados': [],
    'intensivos': []
}


def cargar():
    try:
        with open(RUTA, 'r', encoding='utf-8') as archivo:
            return json.load(archivo)
    except FileNotFoundError:
        # copia, para no modificar la plantilla original
        return copy.deepcopy(DATOS_INICIACION)


def guardar(datos):
    os.makedirs(os.path.dirname(RUTA), exist_ok=True)
    with open(RUTA, 'w', encoding='utf-8') as archivo:
        json.dump(datos, archivo, indent=4, ensure_ascii=False)
