"""Convierte los registros guardados (diccionarios) en objetos de las clases del paquete models."""
from models.paciente_animal import Paciente_animal
from models.paciente_domestico import Paciente_domestico
from models.paciente_canino import Paciente_canino
from models.paciente_hospitalizado import Paciente_hospitalizado
from models.paciente_cuidados_intensivos import Paciente_cuidados_intensivos
from services.base import obtener


def _animal(datos, id_paciente):
    return obtener(datos, 'animales', 'id_paciente', id_paciente, 'un paciente animal')


def _domestico(datos, id_propietario):
    return obtener(datos, 'domesticos', 'id_propietario', id_propietario, 'un paciente domestico')


def _hospitalizado(datos, id_hospitalizado):
    return obtener(datos, 'hospitalizados', 'id_hospitalizado', id_hospitalizado, 'un paciente hospitalizado')


def construir_animal(datos, id_):
    return Paciente_animal(**_animal(datos, id_))


def construir_domestico(datos, id_):
    reg = _domestico(datos, id_)
    return Paciente_domestico(**{**_animal(datos, reg['id_paciente']), **reg})


def construir_canino(datos, id_):
    reg = obtener(datos, 'caninos', 'id_canino', id_, 'un paciente canino')
    dom = _domestico(datos, reg['id_propietario'])
    return Paciente_canino(**{**_animal(datos, dom['id_paciente']), **dom, **reg})


def construir_hospitalizado(datos, id_):
    reg = _hospitalizado(datos, id_)
    dom = _domestico(datos, reg['id_propietario'])
    return Paciente_hospitalizado(**{**_animal(datos, dom['id_paciente']), **dom, **reg})


def construir_intensivo(datos, id_):
    reg = obtener(datos, 'intensivos', 'id_intensivo', id_, 'un paciente en cuidados intensivos')
    hosp = _hospitalizado(datos, reg['id_hospitalizado'])
    dom = _domestico(datos, hosp['id_propietario'])
    return Paciente_cuidados_intensivos(**{**_animal(datos, dom['id_paciente']), **dom, **hosp, **reg})
