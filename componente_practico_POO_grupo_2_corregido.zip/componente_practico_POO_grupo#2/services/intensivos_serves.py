from repository import reps_json
from services import base
from services.objetos import construir_intensivo
from utils import generar_id

TABLA, CLAVE, DESCRIPCION = 'intensivos', 'id_intensivo', 'un paciente en cuidados intensivos'
CAMPOS = ('nivel_gravedad', 'requiere_oxigeno', 'requiere_ventilacion', 'frecuencia_monitoreo_h',
          'temperatura', 'frecuencia_cardiaca', 'frecuencia_respiratoria', 'recargo_porcentaje',
          'equipo_asignado', 'registros_monitoreo')
PADRE = ('id_hospitalizado', 'hospitalizados', 'id_hospitalizado', 'un paciente hospitalizado')


def listar():
    return base.listar(TABLA)

def obtener(id_intensivo):
    return base.obtener(reps_json.cargar(), TABLA, CLAVE, id_intensivo, DESCRIPCION)

def crear(**datos):
    return base.crear(TABLA, CLAVE, generar_id.generar_id_intensivo, datos, padre=PADRE,
                      extras={'registros_monitoreo': []})

def actualizar(id_intensivo, **datos):
    return base.actualizar(TABLA, CLAVE, id_intensivo, datos, DESCRIPCION, padre=PADRE)

def eliminar(id_intensivo):
    return base.eliminar(TABLA, CLAVE, id_intensivo, DESCRIPCION)

def ejecutar(id_intensivo, metodo, *args):
    return base.ejecutar(TABLA, CLAVE, id_intensivo, DESCRIPCION, construir_intensivo, CAMPOS, metodo, args)
