"""Logica comun del CRUD. Cada *_serves.py solo indica su tabla, su clave y sus campos."""
from repository import reps_json


def buscar(datos, tabla, clave, id_):
    for registro in datos[tabla]:
        if registro[clave] == id_:
            return registro
    return None


def obtener(datos, tabla, clave, id_, descripcion):
    registro = buscar(datos, tabla, clave, id_)
    if registro is None:
        raise ValueError(f'no existe {descripcion} con id {id_}')
    return registro


def _verificar_padre(datos, padre, nuevos):
    campo_fk, tabla_padre, clave_padre, descripcion = padre
    obtener(datos, tabla_padre, clave_padre, nuevos[campo_fk], descripcion)


def listar(tabla):
    return reps_json.cargar()[tabla]


def crear(tabla, clave, generar_id, nuevos, padre=None, extras=None):
    datos = reps_json.cargar()
    if padre:
        _verificar_padre(datos, padre, nuevos)
    nuevo_id = generar_id(datos)
    registro = {clave: nuevo_id, **nuevos, **(extras or {})}
    datos[tabla].append(registro)
    reps_json.guardar(datos)
    return nuevo_id


def actualizar(tabla, clave, id_, nuevos, descripcion, padre=None):
    datos = reps_json.cargar()
    registro = obtener(datos, tabla, clave, id_, descripcion)
    if padre:
        _verificar_padre(datos, padre, nuevos)
    registro.update(nuevos)
    reps_json.guardar(datos)
    return True


def eliminar(tabla, clave, id_, descripcion, dependientes=()):
    datos = reps_json.cargar()
    registro = obtener(datos, tabla, clave, id_, descripcion)
    for tabla_hija, campo_fk, nombre_hija in dependientes:
        if any(hijo.get(campo_fk) == id_ for hijo in datos[tabla_hija]):
            raise ValueError(f'no se puede eliminar: tiene {nombre_hija} asociados')
    datos[tabla].remove(registro)
    reps_json.guardar(datos)
    return True


def ejecutar(tabla, clave, id_, descripcion, construir, campos, metodo, args):
    """Arma el objeto de la clase, ejecuta uno de sus metodos y guarda los cambios."""
    datos = reps_json.cargar()
    registro = obtener(datos, tabla, clave, id_, descripcion)
    objeto = construir(datos, id_)
    resultado = getattr(objeto, metodo)(*args)
    for campo in campos:
        registro[campo] = getattr(objeto, campo)
    reps_json.guardar(datos)
    return resultado
