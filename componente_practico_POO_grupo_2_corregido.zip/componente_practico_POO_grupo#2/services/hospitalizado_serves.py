from repository import reps_json
from services import base
from services.objetos import construir_hospitalizado
from utils import generar_id

TABLA, CLAVE, DESCRIPCION = 'hospitalizados', 'id_hospitalizado', 'un paciente hospitalizado'
CAMPOS = ('fecha_ingreso', 'fecha_alta', 'motivo_ingreso', 'diagnostico', 'veterinario_responsable',
          'numero_jaula', 'costo_diario', 'estado_hospitalizacion', 'lista_medicacion')
PADRE = ('id_propietario', 'domesticos', 'id_propietario', 'un paciente domestico')
DEPENDIENTES = (('intensivos', 'id_hospitalizado', 'pacientes en cuidados intensivos'),)


def listar():
    return base.listar(TABLA)

def obtener(id_hospitalizado):
    return base.obtener(reps_json.cargar(), TABLA, CLAVE, id_hospitalizado, DESCRIPCION)

def crear(**datos):
    return base.crear(TABLA, CLAVE, generar_id.generar_id_hospitalizado, datos, padre=PADRE)

def actualizar(id_hospitalizado, **datos):
    return base.actualizar(TABLA, CLAVE, id_hospitalizado, datos, DESCRIPCION, padre=PADRE)

def eliminar(id_hospitalizado):
    return base.eliminar(TABLA, CLAVE, id_hospitalizado, DESCRIPCION, DEPENDIENTES)

def ejecutar(id_hospitalizado, metodo, *args):
    return base.ejecutar(TABLA, CLAVE, id_hospitalizado, DESCRIPCION, construir_hospitalizado,
                         CAMPOS, metodo, args)
