from repository import reps_json
from services import base
from services.objetos import construir_animal
from utils import generar_id

TABLA, CLAVE, DESCRIPCION = 'animales', 'id_paciente', 'un paciente animal'
CAMPOS = ('nombre', 'especie', 'raza', 'sexo', 'fecha_nacimiento', 'peso', 'color',
          'estado_salud', 'fecha_registro')
DEPENDIENTES = (('domesticos', 'id_paciente', 'pacientes domesticos'),)


def listar():
    return base.listar(TABLA)

def obtener(id_animal):
    return base.obtener(reps_json.cargar(), TABLA, CLAVE, id_animal, DESCRIPCION)

def crear(**datos):
    return base.crear(TABLA, CLAVE, generar_id.generar_id_animal, datos)

def actualizar(id_animal, **datos):
    return base.actualizar(TABLA, CLAVE, id_animal, datos, DESCRIPCION)

def eliminar(id_animal):
    return base.eliminar(TABLA, CLAVE, id_animal, DESCRIPCION, DEPENDIENTES)

def ejecutar(id_animal, metodo, *args):
    return base.ejecutar(TABLA, CLAVE, id_animal, DESCRIPCION, construir_animal, CAMPOS, metodo, args)
