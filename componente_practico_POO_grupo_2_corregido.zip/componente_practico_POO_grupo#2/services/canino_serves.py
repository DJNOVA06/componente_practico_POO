from repository import reps_json
from services import base
from services.objetos import construir_canino
from utils import generar_id

TABLA, CLAVE, DESCRIPCION = 'caninos', 'id_canino', 'un paciente canino'
CAMPOS = ('tamanio', 'tipo_pelaje', 'desparasitaciones', 'vacuna_rabia', 'vacuna_parvovirus',
          'raza_peligrosa', 'usar_bozal', 'esta_adiestrado', 'nivel_energia')
PADRE = ('id_propietario', 'domesticos', 'id_propietario', 'un paciente domestico')


def listar():
    return base.listar(TABLA)

def obtener(id_canino):
    return base.obtener(reps_json.cargar(), TABLA, CLAVE, id_canino, DESCRIPCION)

def crear(**datos):
    return base.crear(TABLA, CLAVE, generar_id.generar_id_canino, datos, padre=PADRE)

def actualizar(id_canino, **datos):
    return base.actualizar(TABLA, CLAVE, id_canino, datos, DESCRIPCION, padre=PADRE)

def eliminar(id_canino):
    return base.eliminar(TABLA, CLAVE, id_canino, DESCRIPCION)

def ejecutar(id_canino, metodo, *args):
    return base.ejecutar(TABLA, CLAVE, id_canino, DESCRIPCION, construir_canino, CAMPOS, metodo, args)
