from repository import reps_json
from services import base
from services.objetos import construir_domestico
from utils import generar_id

TABLA, CLAVE, DESCRIPCION = 'domesticos', 'id_propietario', 'un paciente domestico'
CAMPOS = ('propietario_nombre', 'propietario_cedula', 'propietario_telefono', 'propietario_direccion',
          'propietario_correo', 'vacunas', 'fecha_ultima_vacuna', 'esta_esterilizado', 'tiene_microchip')
PADRE = ('id_paciente', 'animales', 'id_paciente', 'un paciente animal')
DEPENDIENTES = (('caninos', 'id_propietario', 'pacientes caninos'),
                ('hospitalizados', 'id_propietario', 'pacientes hospitalizados'))


def listar():
    return base.listar(TABLA)

def obtener(id_domestico):
    return base.obtener(reps_json.cargar(), TABLA, CLAVE, id_domestico, DESCRIPCION)

def crear(**datos):
    return base.crear(TABLA, CLAVE, generar_id.generar_id_domestico, datos, padre=PADRE)

def actualizar(id_domestico, **datos):
    return base.actualizar(TABLA, CLAVE, id_domestico, datos, DESCRIPCION, padre=PADRE)

def eliminar(id_domestico):
    return base.eliminar(TABLA, CLAVE, id_domestico, DESCRIPCION, DEPENDIENTES)

def ejecutar(id_domestico, metodo, *args):
    return base.ejecutar(TABLA, CLAVE, id_domestico, DESCRIPCION, construir_domestico, CAMPOS, metodo, args)
