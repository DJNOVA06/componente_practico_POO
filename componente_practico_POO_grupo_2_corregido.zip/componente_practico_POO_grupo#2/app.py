from services import animal_serves, domestico_serves, canino_serves, hospitalizado_serves, intensivos_serves
from utils import validar_datos

FECHA = 'AAAA-MM-DD'
SI_NO = 'si / no'
FECHA_HOY = 'AAAA-MM-DD, Enter = hoy'

# 'datos' -> campo: ayuda que se muestra al pedirlo
# 'acciones' -> (texto del menu, metodo de la clase, [(dato que se pide, ayuda)])
MENU_ANIMAL = {
    'tipo': 'animal',
    'servicio': animal_serves,
    'datos': {
        'nombre': '', 'especie': '', 'raza': '', 'sexo': 'macho / hembra',
        'fecha_nacimiento': FECHA, 'peso': 'kg', 'color': '',
        'estado_salud': 'bueno / medio / malo', 'fecha_registro': FECHA_HOY,
    },
    'acciones': [
        ('Actualizar estado de salud', 'actualizar_estado_salud', [('nuevo_estado', 'bueno / medio / malo')]),
        ('Registrar peso', 'registrar_peso', [('nuevo_peso', 'kg')]),
    ],
}

MENU_DOMESTICO = {
    'tipo': 'domestico',
    'servicio': domestico_serves,
    'datos': {
        'id_paciente': 'id del paciente animal', 'propietario_nombre': '',
        'propietario_cedula': '10 digitos', 'propietario_telefono': '7 a 10 digitos',
        'propietario_direccion': '', 'propietario_correo': 'opcional',
        'vacunas': 'separadas por coma, opcional', 'fecha_ultima_vacuna': FECHA + ', opcional',
        'esta_esterilizado': SI_NO, 'tiene_microchip': SI_NO,
    },
    'acciones': [
        ('Registrar propietario', 'registrar_propietario',
         [('nombre', ''), ('cedula', '10 digitos'), ('telefono', '7 a 10 digitos'),
          ('direccion', ''), ('correo', 'opcional')]),
        ('Registrar vacuna', 'registrar_vacuna', [('vacuna', ''), ('fecha', FECHA)]),
    ],
}

MENU_CANINO = {
    'tipo': 'canino',
    'servicio': canino_serves,
    'datos': {
        'id_propietario': 'id del paciente domestico', 'tamanio': 'pequeno / mediano / grande',
        'tipo_pelaje': '', 'desparasitaciones': 'fechas ' + FECHA + ' separadas por coma, opcional',
        'vacuna_rabia': SI_NO, 'vacuna_parvovirus': SI_NO, 'raza_peligrosa': SI_NO,
        'usar_bozal': SI_NO, 'esta_adiestrado': SI_NO, 'nivel_energia': 'alto / medio / bajo',
    },
    'acciones': [
        ('Registrar desparasitacion', 'registrar_desparasitacion', [('fecha', FECHA)]),
        ('Calcular edad canina (anios de perro)', 'calcular_edad_canina', []),
    ],
}

MENU_HOSPITALIZADO = {
    'tipo': 'hospitalizado',
    'servicio': hospitalizado_serves,
    'datos': {
        'id_propietario': 'id del paciente domestico', 'fecha_ingreso': FECHA,
        'fecha_alta': FECHA + ', vacio si sigue internado', 'motivo_ingreso': '', 'diagnostico': '',
        'veterinario_responsable': '', 'numero_jaula': '', 'costo_diario': '',
        'estado_hospitalizacion': 'activo / alta medica',
        'lista_medicacion': 'separada por coma, opcional',
    },
    'acciones': [
        ('Calcular dias de hospitalizacion', 'calcular_dias_hospitalizacion', [('fecha_actual', FECHA_HOY)]),
        ('Calcular costo de hospitalizacion', 'calcular_costo_hospitalizacion', [('fecha_actual', FECHA_HOY)]),
    ],
}

MENU_INTENSIVO = {
    'tipo': 'intensivo',
    'servicio': intensivos_serves,
    'datos': {
        'id_hospitalizado': 'id del paciente hospitalizado', 'nivel_gravedad': 'bajo / medio / alto',
        'requiere_oxigeno': SI_NO, 'requiere_ventilacion': SI_NO, 'frecuencia_monitoreo_h': 'cada cuantas horas',
        'temperatura': 'grados C', 'frecuencia_cardiaca': 'latidos/min', 'frecuencia_respiratoria': 'resp/min',
        'recargo_porcentaje': '0 a 100', 'equipo_asignado': 'separado por coma, opcional',
    },
    'acciones': [
        ('Registrar monitoreo', 'registrar_monitoreo',
         [('frecuencia_cardiaca', 'latidos/min'), ('frecuencia_respiratoria', 'resp/min'),
          ('temperatura', 'grados C')]),
        ('Calcular recargo por cuidados intensivos', 'calcular_recargo_cuidados', [('fecha_actual', FECHA_HOY)]),
    ],
}


def a_texto(valor):
    """Convierte un valor guardado a texto editable (para mostrarlo al actualizar)."""
    if isinstance(valor, bool):
        return 'si' if valor else 'no'
    if isinstance(valor, list):
        return ', '.join(str(x) for x in valor)
    if valor is None:
        return ''
    return str(valor)


def pedir_id(mensaje):
    return validar_datos.id_valido(input(mensaje).strip(), 'el id')


def pedir_campo(campo, ayuda, actual=None):
    etiqueta = f' ({ayuda})' if ayuda else ''
    if actual is None:
        return input(f' - {campo}{etiqueta}: ').strip()
    nuevo = input(f' - {campo}{etiqueta} [actual: {actual or "vacio"}]: ').strip()
    if nuevo == '':
        return actual          # Enter = no cambiar
    if nuevo == '-':
        return ''              # '-' = dejar vacio
    return nuevo


def crear_registro(menu):
    datos = {campo: pedir_campo(campo, ayuda) for campo, ayuda in menu['datos'].items()}
    validados = validar_datos.verificar_datos(menu['tipo'], datos)
    nuevo_id = menu['servicio'].crear(**validados)
    print(f'\n - el nuevo registro se ha creado correctamente (id {nuevo_id})...')


def listar_registros(menu):
    lista = menu['servicio'].listar()
    for registro in lista:
        print(f' - {registro}')
    if not lista:
        print('\n - no hay ningun registro...')


def actualizar_registro(menu):
    servicio = menu['servicio']
    id_registro = pedir_id('id del registro que desea actualizar: ')
    actual = servicio.obtener(id_registro)
    print(' (Enter = dejar igual, "-" = dejar vacio)')
    datos = {campo: pedir_campo(campo, ayuda, a_texto(actual[campo]))
             for campo, ayuda in menu['datos'].items()}
    validados = validar_datos.verificar_datos(menu['tipo'], datos)
    servicio.actualizar(id_registro, **validados)
    print('\n - el registro se ha actualizado correctamente...')


def eliminar_registro(menu):
    id_registro = pedir_id('id del registro que desea eliminar: ')
    menu['servicio'].eliminar(id_registro)
    print('\n - el registro se elimino correctamente...')


def ejecutar_accion(menu):
    acciones = menu['acciones']
    id_registro = pedir_id('id del registro: ')
    for numero, (texto, _metodo, _pedidos) in enumerate(acciones, 1):
        print(f'    {numero}. {texto}')
    print('    0. cancelar')
    seleccion = input('ingrese la accion: ').strip()
    if seleccion == '0':
        return
    if not (seleccion.isdigit() and 1 <= int(seleccion) <= len(acciones)):
        raise ValueError('accion no valida')

    texto, metodo, pedidos = acciones[int(seleccion) - 1]
    argumentos = [pedir_campo(nombre, ayuda) for nombre, ayuda in pedidos]
    resultado = menu['servicio'].ejecutar(id_registro, metodo, *argumentos)
    if resultado is None:
        print('\n - accion realizada correctamente...')
    else:
        print(f'\n - {texto}: {resultado}')


ACCIONES_MENU = {
    '1': crear_registro,
    '2': listar_registros,
    '3': actualizar_registro,
    '4': eliminar_registro,
    '5': ejecutar_accion,
}


def sub_menu(nombre, menu):
    while True:
        print(f'\nSISTEMA VETERINARIO: {nombre}')
        print('    1. crear')
        print('    2. listar')
        print('    3. actualizar')
        print('    4. eliminar')
        print('    5. acciones (metodos de la clase)')
        print('    6. volver menu principal')

        tecla = input('ingrese la opcion del menu: ').strip()
        if tecla == '6':
            break
        funcion = ACCIONES_MENU.get(tecla)
        if funcion is None:
            print('\n    - ingrese correctamente la opcion...')
            continue
        try:
            funcion(menu)
        except ValueError as error:
            print(f'\n - error: {error}')


def menu():
    while True:
        print('''
SISTEMA VETERINARIA
1. paciente animal
2. paciente domestico
3. paciente canino
4. paciente hospitalario
5. paciente cuidados intensivos
6. salir
        ''')
        try:
            sel = int(input('ingrese una de las opciones del menu: '))
        except ValueError:
            print('Ingrese correctamente la opcion por favor...')
            continue

        if sel == 1:
            sub_menu('PACIENTE ANIMAL', MENU_ANIMAL)
        elif sel == 2:
            sub_menu('PACIENTE DOMESTICO', MENU_DOMESTICO)
        elif sel == 3:
            sub_menu('PACIENTE CANINO', MENU_CANINO)
        elif sel == 4:
            sub_menu('PACIENTE HOSPITALIZADO', MENU_HOSPITALIZADO)
        elif sel == 5:
            sub_menu('PACIENTE INTENSIVO', MENU_INTENSIVO)
        elif sel == 6:
            print('gracias por usar el programa :D')
            break
        else:
            print('Ingrese correctamente la opcion por favor...')


if __name__ == '__main__':
    menu()
